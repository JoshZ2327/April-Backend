// Backend Server for April Trading Software

const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Sample Portfolio Data Endpoint
app.get('/api/portfolio', (req, res) => {
    res.json([
        { token: 'SOL', amount: 25 },
        { token: 'USDC', amount: 1000 },
        { token: 'ETH', amount: 1.5 }
    ]);
});

// Root Route
app.get('/', (req, res) => {
    res.send('April Trading Backend is running successfully!');
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
